<script src="assets/js/selsubimg.js"></script>
<div id="main-user-img-update">
  <form id="updateimgprofile" action="includes/uploadimgprofile.inc.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="fileToUpload" id="updateimgprofile_file" style="display: none">
    <input type="button" value="Upload Profile Image" class="button" onclick="selectimg('updateimgprofile')">
  </form>
</div>