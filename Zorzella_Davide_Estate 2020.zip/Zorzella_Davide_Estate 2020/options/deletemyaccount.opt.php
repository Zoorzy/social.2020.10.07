<div id="main-user-account-delete">
  <form id="deletemyaccount" action="deletemyaccount.php" method="POST" enctype="multipart/form-data">
    <input type="submit" value="Delete My Account" class="button">
  </form>
</div>