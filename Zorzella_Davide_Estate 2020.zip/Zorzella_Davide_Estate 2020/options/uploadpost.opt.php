<div id="main-user-post-upload">
  <form id="uploadimgpost" action="uploadpost.php" method="POST" enctype="multipart/form-data">
    <input type="submit" value="Upload Post" class="button" name="upload-post">
  </form>
</div>